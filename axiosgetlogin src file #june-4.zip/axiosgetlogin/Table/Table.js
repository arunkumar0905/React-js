import './Table.css';
import download from '../assets/image/download.jpg';
import Header from '../Header';
import { useState } from 'react';

const list =[{
bookName:"harry potter",
price:2000,
available:true
},
{
  bookName:"Witcher",
  price:4000,
  available:true
  },
  {
    bookName:"SpiderMan",
    price:2000,
    available:true
    },
    {
      bookName:"SpiderMan",
      price:2000,
      available:true
      },
      {
        bookName:"SpiderMan",
        price:2000,
        available:true
        }
]
function Table(){

  const[getList,setList] = useState(list);

  const[getForm,setForm] =useState({
    bookName:'',
    price:'',
    available:false

});

const [getEditButton,setEditButton] = useState(false);
const [editId,setId] = useState(-1);

const onDeleteHandler=(index)=>{
let list =[...getList]; //... copying array data
list.splice(index,1); // to delete one data at a time
setList(list);

}

const existingDetails=(index)=>{
setEditButton(true);
setId(index)
setForm({
bookName:getList[index].bookName, // key value pair
price:getList[index].price,
available:getList[index].available

})

}

const onEditHandler=()=>{
let list = [...getList];
list[editId].bookName = getForm.bookName;
list[editId].price = getForm.price;
list[editId].available = getForm.available;
setList(list);
setEditButton(false);
setForm({
  bookName:'',
  price:'',
  available: false
}
)
}

const onChangeHandler=(event)=>{
  //console.log(event.target.checked);
if(event.target.name==="available"){

  setForm({...getForm,[event.target.name]:event.target.checked})

}
else
{
  setForm({...getForm,[event.target.name]:event.target.value})
}

}

const emptyValidation =(value)=>{

if(value){

return true
}
else
{
return false;
}

}

const onSubmitHandler=(event)=>{

    event.preventDefault();
    if(!emptyValidation(getForm.bookName)) 
    {
        alert("Book name cannot be empty");
        return;
    }
    if(!emptyValidation(getForm.price)) //!false = true
    {
        alert("price cannot be empty"); // If true, this alert will trigger
        return;
    }

    if(getEditButton){

      onEditHandler();
    }
    else
{

  setList([...getList,getForm]);
}
  
}

    return (<div>
        <Header/>
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                <div  class="text-center">
                     <h1>Add Book</h1>
                  </div>
              </div>
          </div>
          <div class="row">
            
              <div class="col-md-4">
                <form>
                    <div class="form-group">
                      <label>Book Name  </label>
                      <input type="text" onChange={onChangeHandler} value ={getForm.bookName} class="form-control" name="bookName"/>
                     
                    </div>
                    <div class="form-group">
                      <label> Price  </label>
                      <input type="text" onChange={onChangeHandler} value ={getForm.price} class="form-control" name="price"/>
                     
                    </div>
                  
                    <div class="form-group">
                      <label>Available </label>
                      <input type="checkbox" onChange={onChangeHandler} checked ={getForm.available}  class="form-control" name="available"/>
                     
                    </div>
                  
                  
                    <div class="row">
                        <div class="col-12">
                            <div  class="text-center">
                               <button type="submit" onClick={onSubmitHandler} class="btn btn-outline-success">{getEditButton?"Edit":"Add"}</button>
                              
                            </div>
                           
                        </div>
                    </div>
                   
                  </form>
              </div>
              <div class="col-md-4">

            </div>
              <div class="col-md-4">

              </div>
          </div>
          <div class="row">
              <div class="col-md-1">

              </div>
              <div class="col-md-10">
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">bookName</th>
                        <th scope="col">price</th>
                        <th scope="col">Handle</th>
                        <th scope="col">available</th>
                      </tr>
                    </thead>
                    <tbody>
                      {
                     getList.map((obj,index)=>{

                      return(
                        <tr> 
                        <th scope="row">{index +1}</th>
                        <td>{obj.bookName}</td>
                        <td>{obj.price}</td>
                        <td><i class="fa fa-pencil-square-o" onClick={()=>existingDetails(index)} aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;<i class="fa fa-trash" onClick={()=>onDeleteHandler(index)} aria-hidden="true"></i></td>
                        <td><a href="">{obj.available?"Available":"Not Available"}</a></td>
                      </tr>
                   
                      ) 
                    }
                         
                  
                    )
                   
}
                    </tbody>
                  </table> 
            </div>
            <div class="col-md-1">
                  
            </div>
        </div>
        </div>
    </div>)
}

export default Table;