export default [
    {
        id: "1",
        name: "Davido",
        country: "Nigeria",
        genre: "Afro-Pop",
        albums: "2"
    },
    {
        id: "2",
        name: "AKA",
        country: "South-Africa",
        genre: "Hip-Hop",
        albums: "4"  
    },
    {
        id: "3",
        name: "Seyi Shay",
        country: "Nigeria",
        genre: "R&B",
        albums: "2"
    },
    {
        id: "4",
        name: "Sauti Sol",
        country: "Kenya",
        genre: "Soul",
        albums: "3"
    }
];