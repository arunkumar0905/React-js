import './Register.css';
import Header from '../Header';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const Register=()=>{
    
    const[getForm,setForm] =useState({
        FirstName:'',
        LastName:'',
        Email:'',
        Password:''

    });

    const navigate = useNavigate();

    const onChangeHandler=(event)=>{
setForm({...getForm,[event.target.name]:event.target.value})

    }

    const emptyValidation =(value)=>{

if(value){

    return true
}
else
{
    return false;
}

    }

    const onSubmitHandler=(event)=>{

        event.preventDefault();
        if(!emptyValidation(getForm.FirstName)) 
        {
            alert("First name cannot be empty");
            return;
        }
        if(!emptyValidation(getForm.LastName)) //!false = true
        {
            alert("Last name cannot be empty"); // If true, this alert will trigger
            return;
        }
        if(!emptyValidation(getForm.Email))
        {
            alert("Email name cannot be empty");
            return;
        }
        if(!emptyValidation(getForm.Password))
        {
            alert("Password name cannot be empty");
            return;
        }

        navigate('/login');
    }
   
    
    return (<div>
       
       <Header/>
    <div class="container">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <h1>Sign Up</h1>
                <form>
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" onChange={onChangeHandler} class="form-control" name="FirstName"/>

                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text"onChange={onChangeHandler} class="form-control" name="LastName"/>

                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" onChange={onChangeHandler} class="form-control" name="Email"/>

                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" onChange={onChangeHandler} class="form-control" name="Password"/>

                    </div>
                

                    <button type="submit" onClick={onSubmitHandler} class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="col-4"></div>
        </div>
    </div>
    </div>)
}
export default Register;